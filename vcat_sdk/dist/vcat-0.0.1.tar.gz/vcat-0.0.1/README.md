# VCAT


This project includes functionality for:
- pipelines (data, running, transforms, data, models)